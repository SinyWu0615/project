import axios from 'axios'

axios.defaults.baseURL = 'http://148.70.73.191:9528'

export default axios
