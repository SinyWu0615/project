<template>
    <h1>历史活动</h1>
</template>

<script>
    export default {
        name: "history"
    }
</script>

<style scoped>

</style>
