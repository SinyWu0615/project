<template>
    <h1>修改活动信息</h1>
</template>

<script>
    export default {
        name: "changeInf"
    }
</script>

<style scoped>

</style>
