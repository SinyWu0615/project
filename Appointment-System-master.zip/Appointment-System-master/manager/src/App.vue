<template>
  <div id="app">
    <router-view>

    </router-view>
  </div>
</template>

<script>
  import Vue from 'vue'
  export default ({
      el:'#app',
      data(){
          return {

          }
      }

  })

</script>

<style >
  *{
    margin: 0;
    padding: 0;

  }


</style>
