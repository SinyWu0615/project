// pages/canteen/canteen.js




Page({
  
  /**
   * 页面的初始数据
   */
  data: {
    caten : "",
    imageUrl1: "../../source/餐厅/餐厅.png",
    imageUrl2: "../../source/餐厅/餐厅.png",
    imageUrl3: "../../source/餐厅/餐厅.png",
    imageUrl4: "../../source/餐厅/餐厅.png",
    imageUrl5: "../../source/餐厅/餐厅.png",
    imageUrl6: "../../source/餐厅/餐厅.png"

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    this.num = 1;
    this.imageUrl = "../../source/餐厅/餐厅.png"
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  change:function(){
    
  },
  go1:function(e){
   
    console.log(this.num);
    var cantingId = e.currentTarget.dataset.cantingId;
    this.setData({

      imageUrl1: "../../source/餐厅/餐厅1.png"
    })
    wx.navigateTo({
      url: '../canteenin/canteenin?id=' + cantingId,
      
    })
  },
  go2: function (e) {

    console.log(this.num);
    var cantingId = e.currentTarget.dataset.cantingId;
    this.setData({
      imageUrl2: "../../source/餐厅/餐厅1.png"
    })
    wx.navigateTo({
      url: '../canteenin/canteenin?id=' + cantingId,

    })
  },
  go3: function (e) {

    console.log(this.num);
    var cantingId = e.currentTarget.dataset.cantingId;
    this.setData({
      imageUrl3: "../../source/餐厅/餐厅1.png"
    })
    wx.navigateTo({
      url: '../canteenin/canteenin?id=' + cantingId,

    })
  },
  go4: function (e) {

    console.log(this.num);
    var cantingId = e.currentTarget.dataset.cantingId;
    this.setData({
      imageUrl4: "../../source/餐厅/餐厅1.png"
    })
    wx.navigateTo({
      url: '../canteenin/canteenin?id=' + cantingId,

    })
  },
  go5: function (e) {

    console.log(this.num);
    var cantingId = e.currentTarget.dataset.cantingId;
    this.setData({
      imageUrl5: "../../source/餐厅/餐厅1.png"
    })
    wx.navigateTo({
      url: '../canteenin/canteenin?id=' + cantingId,

    })
  },
  go6: function (e) {

    console.log(this.num);
    var cantingId = e.currentTarget.dataset.cantingId;
    this.setData({
      imageUrl6: "../../source/餐厅/餐厅1.png"
    })
    wx.navigateTo({
      url: '../canteenin/canteenin?id=' + cantingId,

    })
  }



})