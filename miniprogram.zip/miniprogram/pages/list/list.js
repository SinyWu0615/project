// pages/list/list.js
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    data:{},
    isgood:false,
    count:0,
    image:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that=this;
    const send=wx.cloud.database().collection('send');
    send.doc(app.globalData.listId).get({
        success(res) {
          that.setData({
            data:res.data,
            count:res.data.userGood.length
          })
         
          if(res.data.userGood.indexOf(app.globalData.openId)>-1){
            that.setData({
              isgood:true
            })
          }

          console.log(res.data)
        }
      })

    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  good:function(){
    const db=wx.cloud.database();
    const _ = db.command;
    
    db.collection('send').doc(app.globalData.listId).update({
      data: {
        userGood: _.push(app.globalData.openId)
      },
      success(res) {
      
      }
    })

    this.setData({
      isgood:true,
      count:this.data.count+1
    })
  },

  nogood:function(){
    this.setData({
      isgood:false,
      count:this.data.count-1
    })
    const db = wx.cloud.database();
    const _ = db.command;
    db.collection('send').doc(app.globalData.listId).update({
      data: {
        userGood: _.pop(app.globalData.openId)
      },
      success(res) {

      }
    })

  },


  previewImage: function (e) {
    var current = e.target.dataset.src;
    var url=current.split(' ')
    console.log(url)
    wx.previewImage({
      current: current, // 当前显示图片的http链接
      urls: url// 需要预览的图片http链接列表
    })
  },  

  delete:function(e){
    const send=wx.cloud.database().collection('send');
    send.doc(app.globalData.listId).remove({
      seccess(res){
        
      },
      complete(){
        wx.redirectTo({
          url: '../content/content',
        })
        console.log('aaa')
        wx.showToast({
          title: '删除成功',
        })
      }
    })

  }



})