const app=getApp();

Page({
  data:{
    releaseFocus: false,
    textarea:""
  },
  onLoad: function (options) {
    
    this.setData({
      diet_id: options.id
    })
  },


  onShow:function(options){
    var that = this;
    wx.request({
      url: 'http://112.74.41.167:8000/hanjiaxing/wwwroot/shaheweidao/shaheweidao/wxshahe/dish',
      data: {
        diet_id: that.data.diet_id,
        user_id: app.globalData.openId
      },
      header: {
        'content-type': 'json'
      },
      success: function (res) {
        console.log(res.data)
        // console.log('asss')
        // console.log(res.data.diet_evaluation)
        that.setData({
          dish: res.data,
          releaseFocus: false,
          textarea:""
        })
      }
    })
    const _ = wx.cloud.database().command
    const c = wx.cloud.database().collection('user')

    c.where({ user_id: app.globalData.openId }).get({
      success: function (res) {
        var a = res.data[0]

        c.doc(res.data[0]._id).update({
          data: {
            history: _.unshift(that.data.dish)
          },
          success: function (res) {

            if (a.history.length > 50) {
              console.log(a.history.length)
              c.doc(a._id).update({
                data: {
                  history: _.pop()
                }
              })

            }
          }
        })
      }
    })

  },

  update_zan1: function (e) {
    console.log(e.currentTarget.dataset.zan)
    var that = this
    // var zan = e.currentTarget.dataset.zan
    that.setData({
      'dish.diet_praise': false
    })
    
    wx.request({
      url: 'http://112.74.41.167:8000/hanjiaxing/wwwroot/shaheweidao/shaheweidao/wxshahe/dish/praise',
      data:{
        diet_id:that.data.diet_id,
        diet_praise: !that.data.dish.diet_praise,
        user_id: app.globalData.openId
      },
      hearder:{
        'Content-Type':'application/json'
      },
      success:function(res){
        // console.log(res)
        console.log("success!")
        that.setData({
          praise_num:res.data.praise_num
        })

      }
    })

    
  },


  update_zan2: function (e) {
    console.log(e.currentTarget.dataset.zan)
    var that = this
    // var zan = e.currentTarget.dataset.zan
    that.setData({
      'dish.diet_praise': true
    })

    wx.request({
      url: 'http://112.74.41.167:8000/hanjiaxing/wwwroot/shaheweidao/shaheweidao/wxshahe/dish/praise',
      data: {
        diet_id: that.data.diet_id,
        diet_praise: !that.data.dish.diet_praise,
        user_id: app.globalData.openId
      },
      hearder: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        // console.log(res)
        console.log("success!")
        that.setData({
          praise_num: res.data.praise_num
        })

      }
    })


  },
  input(event) {
    var value = event.detail.value;
    let that = this;
    that.setData({
      textarea: value
    });
  },
  hideInput: function (e) {
    this.setData({
      releaseFocus: false
    });
  },
  btnclick: function (e) {
    var that = this
    //console.log(that.evaluate)
    if (this.data.textarea != "") {
      console.log(this.data.diet_id, app.globalData.openId, this.data.textarea)
      wx.request({
        url: 'http://112.74.41.167:8000/hanjiaxing/wwwroot/shaheweidao/shaheweidao/wxshahe/comment/',
        data:{
          diet_id:this.data.diet_id,
          user_id: app.globalData.openId,
          diet_comment:this.data.textarea
        },
        success:function(res){
          var diet_id = that.data.diet_id;
          wx.showToast({
            title: '评论成功', success: res => {
              let pages = getCurrentPages() //获取页面数组

              let curPage = pages[pages.length - 1]  //获取当前页

              curPage.onShow() //手动调用生命周期函数
            }
          })

        }
      })
    }
    else {
      wx.showToast({
        title: '请输入评论',
        image: '../../images/error.png'
      })
    }
  },
  eva: function (e) {
    this.setData({
      releaseFocus: true
    })
  }

})
