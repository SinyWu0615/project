// pages/content/content.js
var app=getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    data: [],
    tasks:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

    var that = this;
    const send = wx.cloud.database().collection('send');
    
  
    send.orderBy('time', 'desc').limit(20).get({
      success(res) {
        // res.data 是一个包含集合中有权限访问的所有记录的数据，不超过 20 条
        console.log(res.data);
        that.setData({
          data: res.data
        });
        that.check();
      }
    });
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  go:function(){
    wx.navigateTo({
      url: '../send/send',
    })
  },

  goList:function(e){

    app.setGlobalData({
      listId:e.currentTarget.dataset.id
    });
    wx.navigateTo({
      url: '../list/list',
    })
  },


})