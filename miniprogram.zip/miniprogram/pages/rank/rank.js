// pages/rank/rank.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isCurrent:1,
    rank:{
      0:{
      diet_cook_id: 1001,
      diet_id: 1,
      diet_image: "",
      diet_location: "",
      diet_material: "",
      diet_name: "",
      diet_praise: 5,
      }
    },
    chief:{
      0: {
      cook_id: 6666,
      cook_name: 'wxy',
      cook_image: '../../images/usrimg.jpg',
      cook_brief_content: '来自新东方',
      cook_praise: 100
      }
    },
   
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //加载排行
    var that = this;
    
      wx.request({
        url:'http://112.74.41.167:8000/hanjiaxing/wwwroot/shaheweidao/shaheweidao/wxshahe/rank/praise/',
        method: "GET",
        header: {
          'Content-Type': 'application/json;charset=UTF-8;'
        },
        success: function (res) {
          console.log(res);
          that.setData({
            rank:res.data
          })
        },
        fail: function () {
          
        }
      })

      wx.request({
        url: 'http://112.74.41.167:8000/hanjiaxing/wwwroot/shaheweidao/shaheweidao/wxshahe/rank/cook/',
        method: "GET",
        header: {
          'Content-Type': 'application/json;charset=UTF-8;'
        },
        success: function (res) {
          console.log(res);
          that.setData({
            chief: res.data
          })
        },
        fail: function () {

        }
      })

    

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  tap1:function(){
    this.setData({
      isCurrent:1
    })
  },
  tap2: function(){
    this.setData({
      isCurrent: 2
    })
  },


})