// pages/test/test.js


Page({

  /**
   * 页面的初始数据
   */
  data: {
    canteen:'',
    indexSize: 0,
    indicatorDots: false,
    autoplay: false,
    duration: 0, //可以控制动画
    list: '',
    detail: {}
  },
  change(e) {
    this.setData({
      indexSize: e.detail.current
    })
  },
  scrollTo(e) {
    console.log(this.diet)
    this.setData({
      indexSize: e.target.dataset.index
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    var that = this;
    var cantingName = options.id;
    //console.log(cantingName);
    wx.request({
      url: 'http://112.74.41.167:8000/hanjiaxing/wwwroot/shaheweidao/shaheweidao/wxshahe/canteen/?keyword='+ cantingName,
      success: function (res) {
        console.log(res.data);
        that.diet = res.data;
        that.setData({
          detail: res.data
        });
    
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    //console.log(console.log(this.diet))
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  jump: function (e) {
    var that = this;
    var dishId = e.currentTarget.dataset.dishId;
    console.log(that.data);
    console.log(dishId);
    
    wx.navigateTo({
      url: '../dish/dish?id=' + dishId,
    })
  }
})