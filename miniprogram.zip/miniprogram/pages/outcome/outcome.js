Page({
  data: {
    history: []
  },
  
  onLoad:function(options){
    
  },
  jump: function (e) {
    var that = this
    var dishId = e.currentTarget.dataset.dishId;
    console.log(dishId)
    wx.navigateTo({
      url: '../dish/dish?id=' + dishId,
    })
  }
  
})