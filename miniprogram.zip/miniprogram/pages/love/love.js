const app = getApp()
Page({
  data: {

  },
  onLoad:function(){
    var that = this
    wx.request({
      url: 'http://112.74.41.167:8000/hanjiaxing/wwwroot/shaheweidao/shaheweidao/wxshahe/love/',
      data: {
        openid: app.globalData.openId
      },
      header: {
        'content-type': 'json'
      },
      success:function(res){
        console.log(res)
        that.setData({
          dish : res.data
        })
      }

    })
  },
  jump: function (e) {
    var that = this
    var dishId = e.currentTarget.dataset.dishId;
    console.log(dishId)
    wx.navigateTo({
      url: '../dish/dish?id=' + dishId,
    })
  }
})