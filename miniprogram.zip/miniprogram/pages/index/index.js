const app=getApp()

Page({

  data : {
    
    text:"提交",
     value:""
  },
  

  sleep:function(delay) {
    var start = (new Date()).getTime();
    while((new Date()).getTime() - start < delay) {
  continue;
}
},
  //下拉刷新
  onPullDownRefresh: function () {
   console.log("???")
    wx.stopPullDownRefresh();
    
  },

  onLoad:function(){
    var that = this;
    
    wx.request({
      url:              'http://112.74.41.167:8000/hanjiaxing/wwwroot/shaheweidao/shaheweidao/wxshahe/index',
      success: function (res) {
        console.log(res.data);
        that.setData({
          diet:res.data
        
        })
      }
    })

  },
  input: function (e) {
    this.setData({
      value: e.detail.value
    });
  },

  btnclick:function(e){
    var value = e.currentTarget.dataset.value;
    var that =this
    console.log(value)
    if (this.data.value != ""){
      wx.navigateTo({
        url: '../search/search?value='+value,
      })
      that.setData({
        value:this.data.value
      })
    }
    else{
      wx.showToast({
        title: '请输入关键字',
        image:'../../images/error.png'
      })
    }
  },

  canteen:function(){
    wx.navigateTo({
      url: '../canteen/canteen',
    })
  },
  anonce:function(){
    wx.navigateTo({
      url: '../content/content',
    })
  },
  character:function(){
    wx.navigateTo({
      url: '../character/character',
    })
  },
  dish:function(event){
    var dishId = event.currentTarget.dataset.dishId
    // console.log(dishId)
    
    wx.navigateTo({
      url: '../dish/dish?id='+dishId,
    })

  },


  
})