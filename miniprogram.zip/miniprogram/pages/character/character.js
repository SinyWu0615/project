const app = getApp();
Page({
  data : {
    show:false,
    cook:[
      {
        "content":"川菜",
        "id":1001
      },
      {
        "content": "鲁菜",
        "id": 1002
      },
      {
        "content": "粤菜",
        "id": 1003
      },
      {
        "content": "闽菜",
        "id": 1004
      },
      {
        "content": "苏菜",
        "id": 1005
      },
      {
        "content": "浙菜",
        "id": 1006
      },
      {
        "content": "湘菜",
        "id": 1007
      },
      {
        "content": "徽菜",
        "id": 1008
      }
    ],
    taste : [
      {
        "content": "咸鲜",
        "id": 2001
      },
      {
        "content": "椒麻",
        "id": 2002
      },
      {
        "content": "香咸",
        "id": 2003
      },
      {
        "content": "椒盐",
        "id": 2004
      },
      {
        "content": "五香",
        "id": 2005
      },
      {
        "content": "鱼香",
        "id": 2006
      },
      {
        "content": "清真",
        "id": 2007
      }
    ],
    kind:[
      {
        "content":"菜",
        "id":3001
      },
      {
        "content": "米饭",
        "id":3002
      },
      {
        "content": "面食",
        "id":3003
      },
      {
        "content": "米粉",
        "id":3004
      },
      {
        "content": "汤",
        "id":3005
      },
      {
        "content": "粥",
        "id":3006
      },
      {
        "content": "杂粮",
        "id":3007
      },
      {
        "content": "饮品",
        "id":3008
      }
    ],
    price: [
      {
        "content": "0~5",
        "id": 4001
      },
      {
        "content": "6~10",
        "id": 4002
      },
      {
        "content": "11~15",
        "id": 4003
      },
      {
        "content": "16~20",
        "id": 4004
      }
    ],
    truth:[
        {"cook" : 0 ,"taste": 0, "kind": 0,"price": 0}
    ],
    dish:[]
  },
  

  cookTap: function (e) {
    //console.log(e.currentTarget.dataset.cookId)
    var that = this
    var this_checked = e.currentTarget.dataset.cookId
    var cookList = this.data.cook//获取Json数组
    for (var i = 0; i < cookList.length; i++) {
      if (cookList[i].id == this_checked) {
        cookList[i].checked = true;//当前点击的位置为true即选中
        
      }
      else {
        cookList[i].checked = false;//其他的位置为false
      }
    }

    

    for (var i = 0; i < cookList.length; i++) {
      if (cookList[i].id == this_checked) {
        that.setData({
          cook: cookList,
          'truth.cook':i+1
        })
      }
    }

    
    //console.log(this.data.truth)
  },
  tasteTap: function (e) {
    //console.log(e.currentTarget.dataset.cookId)
    var that = this
    var this_checked = e.currentTarget.dataset.tasteId
    var tasteList = this.data.taste//获取Json数组
    for (var i = 0; i < tasteList.length; i++) {
      if (tasteList[i].id == this_checked) {
        tasteList[i].checked = true;//当前点击的位置为true即选中

      }
      else {
        tasteList[i].checked = false;//其他的位置为false
      }
    }



    for (var i = 0; i < tasteList.length; i++) {
      if (tasteList[i].id == this_checked) {
        that.setData({
          taste: tasteList,
          'truth.taste': i + 1
        })
      }
    }


    //console.log(this.data.truth)
  },
  kindTap: function (e) {
    //console.log(e.currentTarget.dataset.cookId)
    var that = this
    var this_checked = e.currentTarget.dataset.kindId
    var kindList = this.data.kind//获取Json数组
    for (var i = 0; i < kindList.length; i++) {
      if (kindList[i].id == this_checked) {
        kindList[i].checked = true;//当前点击的位置为true即选中

      }
      else {
        kindList[i].checked = false;//其他的位置为false
      }
    }



    for (var i = 0; i < kindList.length; i++) {
      if (kindList[i].id == this_checked) {
        that.setData({
          kind: kindList,
          'truth.kind': i + 1
        })
      }
    }


    //console.log(this.data.truth)
  },
  priceTap: function (e) {
    //console.log(e.currentTarget.dataset.cookId)
    var that = this
    var this_checked = e.currentTarget.dataset.priceId
    var priceList = this.data.price//获取Json数组
    for (var i = 0; i < priceList.length; i++) {
      if (priceList[i].id == this_checked) {
        priceList[i].checked = true;//当前点击的位置为true即选中

      }
      else {
        priceList[i].checked = false;//其他的位置为false
      }
    }



    for (var i = 0; i < priceList.length; i++) {
      if (priceList[i].id == this_checked) {
        that.setData({
          price: priceList,
          'truth.price': i + 1
        })
      }
    }


    //console.log(this.data.truth)
  },
  sub:function(e){
    var that = this
    console.log(that.data.truth);

    that.setData({
      show:true
    })
    console.log(that.data.show)
    wx.request({
      url: 'http://112.74.41.167:8000/hanjiaxing/wwwroot/shaheweidao/shaheweidao/wxshahe/character/',
      data: {
        //check:that.data.truth
        user_id: app.globalData.openId,
      },
      success:function(res){

        that.setData({
          dish:res.data
        })
        console.log(that.data.dish)
        console.log("...success...")
      },
      fail:function(){
        console.log("...failed...")
      }
    })
   
  },

  jump: function (e) {
    var that = this
    var dishId = e.currentTarget.dataset.dishId;
    console.log(dishId)
    wx.navigateTo({
      url: '../dish/dish?id=' + dishId,
    })
  }
})