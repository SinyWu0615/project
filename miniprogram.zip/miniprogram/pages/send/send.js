// pages/send/send.js
const app=getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    title: '',
    image: [],
    content: '',
    imageID: '',
    userInfo:{},
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo
      })
    }
    
    console.log(this.data.userInfo)
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },


  // onShow: function () {
  //   wx.navigateBack({
  //     delta: 99
  //   })
  // },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  uploadImage: function () {
    var that = this;
    wx.chooseImage({
      count: 1,
      success: function (res) {
        that.setData({
          image: res.tempFilePaths
        })
      },

    })

  },

  inputTitle:function(e){
    this.setData({
      title:e.detail.value
    })
  },
  inputContent:function(e){
    this.setData({
      content:e.detail.value
    })
  },

  confirm: function () {
    var that = this;
    if(!this.data.title){
      wx.showToast({
        title: '标题不为空',
        icon:'loading',
        duration:1000
      })
      return;
    }
    wx.showToast({
      title: '上传中',
      icon: 'loading',
      duration: 3000
    })
   
    if(this.data.image.length!=0){//如果上传了图片
      
        
     const name = Math.random() * 1000000;
      const cloudPath = "content/"+name + this.data.image[0].match(/\.[^.]+?$/)[0]
     wx.cloud.uploadFile({
      cloudPath: cloudPath, // 上传至云端的路径
      filePath: this.data.image[0], // 小程序临时文件路径
      success: res => {
        // 返回文件 ID
        console.log(res.fileID);
        
        that.setData({
          imageID: res.fileID
        });
        const db = wx.cloud.database();
        const send = db.collection('send');
        var time=new Date();
        send.add({
          data: {
            user:this.data.userInfo,
            title: this.data.title,
            content: this.data.content,
            image: this.data.image,
            imageID: this.data.imageID,
            date: time.getFullYear() + '-' + time.getMonth() + '-' + time.getDate(),
            userGood:[],
            time:time
          },

          success(res) {
            wx.showToast({ // 显示Toast
              title: '上传成功',
              icon: 'success',
              duration: 3000
            })
            
            console.log(getCurrentPages())
            wx.navigateBack({
              delta:1
            })
            // wx.redirectTo({
            //   url: '../content/content',
            // })
            this.setData({
              image:[]
              
            })
          },
        });
      },
      fail: console.error
     });
    }else{//如果无图片
      const db = wx.cloud.database();
      const send = db.collection('send');
      var time=new Date();
      send.add({
        data: {
          user: this.data.userInfo,
          title: this.data.title,
          content: this.data.content,
          image: [],
          imageID: [],
          date: time.getFullYear()+'-'+time.getMonth()+'-'+time.getDate(),
          userGood:[],
          time:time
        },
        success(res) {
          wx.showToast({ // 显示Toast
            title: '上传成功',
            icon: 'success',
            
          })

          console.log(getCurrentPages())
          wx.navigateBack({
            delta: 1
          })
          // wx.redirectTo({
          //   url: '../content/content',
          // })
          this.setData({
            image: []
          })
        },
      });
    }
    
   
  }

})