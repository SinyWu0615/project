const app=getApp()
Page({
  data: {
    history: [
      
    ]
  },
  
onLoad:function(){
  var that=this;
  //var user_id=app.globalData.openId
  wx.request({
    url: 'http://112.74.41.167:8000/hanjiaxing/wwwroot/shaheweidao/shaheweidao/wxshahe/history',
    data: {
      openid: app.globalData.openId,
    },
    header: {
      'content-type': 'json'
    },
    success:function(res){
      console.log(res)
      that.setData({
        history: res.data
      })
    }
  })
},


  jump: function (e) {
    var that = this
    var dishId = e.currentTarget.dataset.dishId;
    console.log(dishId)
    wx.navigateTo({
      url: '../dish/dish?id=' + dishId,
    })
  }
})