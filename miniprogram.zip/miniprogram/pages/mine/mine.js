const app=getApp();
Page({
  data: {
    usr: {
      "img": "../../images/usrimg.jpg",
      "id": "monster"
    }
  },
  onLoad: function () {
    console.log(app.globalData.userInfo)
    this.setData({
      usr:app.globalData.userInfo
    })

  },

  history: function (e) {
    var id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '../history/history?id=' + id,
    })
  },
  love: function (e) {
    var id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '../love/love?id=' + id,
    })
  },
  feedback: function (e) {
    var id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '../feedback/feedback?id=' + id,
    })
  },
  help: function () {
    wx.navigateTo({
      url: '../help/help',
    })
  }
})