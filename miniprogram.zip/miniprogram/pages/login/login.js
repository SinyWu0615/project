const app = getApp()

Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  //事件处理函数
  bindViewTap: function () {
    console.log(this.data.userInfo)
    wx.cloud.callFunction({
      // 云函数名称
      name: 'login',
      // 传给云函数的参数
      data: {

      },
      success(res) {
        console.log(app.globalData)
        app.globalData.openId = res.result.userInfo.openId
        wx.request({
          url: 'http://112.74.41.167:8000/hanjiaxing/wwwroot/shaheweidao/shaheweidao/wxshahe/login',
          data: {
            openid: app.globalData.openId,
            nickName:app.globalData.userInfo.nickName,
            image: app.globalData.userInfo.avatarUrl
          },
          header: {
            'content-type': 'json'
          },
          success: function (res) {
            console.log(res.data)
            app.globalData.isManager=res.data.manager
          }
        })
      },
      fail: console.error
    })


    wx.switchTab({
      url: '../index/index',
    })
    
  },
  onLoad: function () {

   
  },
  getUserInfo: function (e) {
    console.log(e.userInfo)
    this.setData({
      userInfo: e.userInfo,
      hasUserInfo: true
    })
  }
})
