Page({

  /**
   * 页面的初始数据
   */
  data: {
    value:"",
    textarea:"",
    length: 0,
    noteMaxLen: 200,         //详细地址的字数限制
    currentNoteLen: 0,
    tempFilePaths:"",
    parameter: [
      {
        "id": "1",
        "text": "菜品信息"
      },
      {
        "id": "2",
        "text": "食堂问题"
      },
      {
        "id": "3",
        "text": "通知问题"
      },
      {
        "id": "4",
        "text": "账户问题"
      },
      {
        "id": "5",
        "text": "使用问题"
      },
      {
        "id": "6",
        "text": "其它问题"
      }
    ]
  },
  connect(event) {
    var value = event.detail.value,
      len = parseInt(value.length);
    let that = this;
    that.setData({
      value: value
    });
  },

  btnclick: function (e) {
    var that = this;
    //console.log(that.value);
    

    if (that.data.value.length != 0) {
      wx.request({
        url: 'http://112.74.41.167:8000/hanjiaxing/wwwroot/shaheweidao/shaheweidao/wxshahe/feedback',
        data:{
          mesimage: that.data.tempFilePaths,
          message:that.data.value,
          mesclass:that.data.parameter,
          mestext:this.data.textarea,
        }
      })
      console.log(that.data);
      wx.navigateBack({
        url: '../mine/mine' ,
      })
      wx.showToast({
        title: '提交成功',
        image: '../../images/error.png'
      })
    }
    else {
      wx.showToast({
        title: '请输入关键字',
        image: '../../images/error.png'
      })
    }
  },

  upload: function () {
    let that = this;
    wx.chooseImage({
      count: 9, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: res => {
        wx.showToast({
          title: '正在上传...',
          ivalue: 'loading',
          mask: true,
          duration: 1000
        })
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        let tempFilePaths = res.tempFilePaths;
        that.setData({
          tempFilePaths: tempFilePaths
        })

      }
    })
  },

  input(event) {
    var value = event.detail.value,
      len = parseInt(value.length);
    let that = this;
    that.setData({
      currentNoteLen: len,
      textarea:value
    });
  },
  parameterTap: function (e) {//e是获取e.currentTarget.dataset.id所以是必备的，跟前端的data-id获取的方式差不多
    var that = this
    var this_checked = e.currentTarget.dataset.id
    var parameterList = this.data.parameter//获取Json数组
    for (var i = 0; i < parameterList.length; i++) {
      if (parameterList[i].id == this_checked) {
        parameterList[i].checked = true;//当前点击的位置为true即选中
      }
      else {
        parameterList[i].checked = false;//其他的位置为false
      }
    }
    that.setData({
      parameter: parameterList
    })
  }
})