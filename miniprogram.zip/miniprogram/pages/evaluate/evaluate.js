Page({
  /**
   * 页面的初始数据
   */
  data: {
    isInput: true,
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },
  /**
   * 点击回复
   */
  hideInput: function (e) {
    this.setData({
      isInput: false
    });
  }
})